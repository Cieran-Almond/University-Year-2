import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;


public class IDLeaf extends ExpTree {

    //constructor for lookuptable

    public static Map<Character, Integer> lookupTable;

    public IDLeaf(char c){
        super(c, null, null);
    }

    //returns the id, evaluates characters based on identifier
    @Override
    public int Evaluate() {
        if (LetTree.let = false) {
            String alpha = "ZXWVUTSRQPONMLKJIHGFEDCBA";
            int eval = alpha.indexOf((char) this.getData());
            return eval;
        }
        if (lookupTable.get(this.getData()) == null) {
            System.out.println("Warning: You should define all identifiers");
            return 0;
        } else {
            return lookupTable.get(this.getData());
        }
    }

}