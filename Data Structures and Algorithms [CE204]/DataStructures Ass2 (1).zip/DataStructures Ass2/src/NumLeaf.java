//each operand class extends operatortree to invoke constructor of parent class

public class NumLeaf extends ExpTree {

    //constructor
    public NumLeaf(int n) {
        super(n, null, null);
    }

    //returns int inside the leaf
    @Override
    public int Evaluate() {
        return (int) this.getData();
    }

}