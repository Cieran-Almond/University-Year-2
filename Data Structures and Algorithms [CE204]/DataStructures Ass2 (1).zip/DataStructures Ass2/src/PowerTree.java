//each operand class extends operatortree to invoke constructor of parent class

public class PowerTree extends OperatorTree {

    //constructor
    public PowerTree(ExpTree l, ExpTree r) {
        super(l, r, '*');
    }
}