public class AndTree extends ExpTree {

    //returns new and with children l, r

    public AndTree(ExpTree l, ExpTree r) {
        super("And", l, r);
    }

    @Override
    public int Evaluate() {
        int eval = 0;
        if (this.r != null) eval = this.r.Evaluate();
        if (this.l != null) eval = eval + this.l.Evaluate();
        return eval;
    }

}