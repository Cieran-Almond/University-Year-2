

// this method should return a new definition node with identifier c and child t
// gets character and data assigned to character, then evalatuates with correct operands
public class DefTree extends ExpTree {

    public DefTree(IDLeaf l, ExpTree r) {
        super("=", l, r);
    }

    @Override
    public int Evaluate() {
        IDLeaf.lookupTable.put((Character) l.getData(), r.Evaluate());
        return 0;
    }
}