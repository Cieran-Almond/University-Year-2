//each operand class extends operatortree to invoke constructor of parent class

public class ModTree extends OperatorTree {

    //constructor
    public ModTree(ExpTree l, ExpTree r) {
        super(l, r, '%');
    }
}