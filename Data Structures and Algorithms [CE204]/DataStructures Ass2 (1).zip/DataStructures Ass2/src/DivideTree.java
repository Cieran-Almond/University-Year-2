
//each operand class extends operatortree to invoke constructor of parent class
public class DivideTree extends OperatorTree {
    public DivideTree(ExpTree l, ExpTree r) {
        super(l, r, '/');
    }
}