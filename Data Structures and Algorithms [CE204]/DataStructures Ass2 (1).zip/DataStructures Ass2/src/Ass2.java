

public class Ass2 {

    //do for user input and name declaration
    public static void main(String[] args) {
        Parser myParser = new Parser();
        System.out.println("CE204 Ass2:\n" +
                "Candidate: Cieran Almond, 164959");
        char in;
        /*do output, parseline and evaluate expressions
         and print post order, then pre order.
         Output error if anything is entered that
         cant be handled.
         */


        do{
            LetTree.let = false;
            System.out.println();
            System.out.println("Welcome to Cieran's " +
                    "evaluation programme.\nPlease type an expression:");
            try {
                ExpTree myTree = myParser.parseLine();
                System.out.println("Expression: " + myTree);
                try {
                    System.out.println("Evaluates To: " + myTree.Evaluate());
                } catch (ArithmeticException e){
                    System.out.println(e.toString());
                }
                System.out.println("Post-order: " + myTree.postOrder());
                System.out.println("Pre-order: " + myTree.preOrder());
            } catch (ParseException p) {
                System.out.println(p.toString() + '\n');
            }
            //prompt the user for new expression
            System.out.print("Another Expression? (y/n) : ");
            try {in = myParser.getLine().charAt(0);}
            catch (Exception e) {
                System.out.println("Input Invalid");
                in = 'n';
            }
        }  while (in == 'y');
        System.out.println("\nExiting...");
    }

}