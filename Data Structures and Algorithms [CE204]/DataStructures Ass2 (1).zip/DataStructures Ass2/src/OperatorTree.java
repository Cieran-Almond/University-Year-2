public abstract class OperatorTree extends ExpTree {


    public OperatorTree(ExpTree l, ExpTree r, char sign){
        super(sign, l, r);
    }


    /*returns the value of the children inside the current
    node with the appropriate operand
     */
    @Override
    public int Evaluate(){
        int eval = 0;
        int left = this.l.Evaluate();
        int right = this.r.Evaluate();
        switch ((char) this.getData()){
            case '+':
                eval = left+right;
                break;
            case '-':
                eval = left-right;
                break;
            case '*':
                eval = left*right;
                break;
            case '/':
                eval = left/right;
                break;
            case '%':
                eval = left%right;
                break;
            case '^':
                eval = left^right;
                break;
        }
        return eval;
    }

}
