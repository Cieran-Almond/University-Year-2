import java.util.HashMap;


/*letree looks up idleaf table and calls evaluate method
 to evaluate operands specified by user.
 */
public class LetTree extends ExpTree{

    public static boolean let;
    public LetTree(ExpTree l, ExpTree r) {
        super("Let", l, r);
        IDLeaf.lookupTable = new HashMap<>();
    }

    @Override
    public int Evaluate() {
        let = true;

        return Evaluate();
    }


}