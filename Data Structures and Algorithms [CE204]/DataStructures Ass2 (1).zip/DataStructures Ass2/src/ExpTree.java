public abstract class ExpTree<T> {

    //data taken from slides
    private T Data;
    public T getData(){return Data;}
    protected ExpTree l;
    protected ExpTree r;

    //constructor taken from slides, calls children class with super
    public ExpTree(T Data, ExpTree l, ExpTree r){
        this.Data=Data;
        this.l = l;
        this.r = r;
    }

    //overriden to supply int value
    public abstract int Evaluate();{

    }


    //string representation of tree inorder
    @Override
    public String toString(){
        String string = new String();
        string = inOrderTraverse(this, string, true);
        return string;
    }

    /*completes an inordertravelersal of expression
    and reconstructs in exptree, str and first methods.
    taking brackets into consideration
     */

    public String inOrderTraverse(ExpTree expTree, String string, boolean first){
        if (expTree.l != null){ //check left node
            if (expTree.getClass() != LetTree.class && expTree.getClass() != AndTree.class && expTree.getClass() != DefTree.class) {
                if (!first) string = string + "(";
                string = inOrderTraverse(expTree.l, string, false);
            }
            else string = inOrderTraverse(expTree.l, string, true);
        }
        if (expTree.getData() == "Let" || expTree.getData() == "And") string = string + " " + expTree.getData() + " ";
        else string = string + expTree.getData();

        if (expTree.r != null){
            if (expTree.getClass() != LetTree.class && expTree.getClass() != AndTree.class && expTree.getClass() != DefTree.class) {
                string = inOrderTraverse(expTree.r, string, false);
                if (!first) string = string + ")";
            } else
                string = inOrderTraverse(expTree.r, string, true);
        }
        return string;  //return constructed string
    }

   //reconstructs string in reverse polish
    public String preOrder(){
        String string = new String();
        string = preTraverse(this, string);
        return string;
    }

    public String postOrder(){
        String string = new String();
        string = postTraverse(this, string);
        return string;
    }

    //uses postOrder to consturct a string in posttraversal
    public String postTraverse(ExpTree expTree, String string){
        if (expTree.l != null){ //check left
            string = preTraverse(expTree.l, string);}
        if (expTree.r != null && expTree.Data != "Let"){ //check right
            string = preTraverse(expTree.r, string);}
        if (expTree.Data != "Let" && expTree.Data != "And")
            string = string + " " + expTree.getData(); //get node data
        return string;  //return constructed string
    }

   //uses preOrder to construct a string in pretraversal
    public String preTraverse(ExpTree expTree, String string){
        if (expTree.Data != "Let" && expTree.Data != "And")
            string = string + " " + expTree.getData(); //get node data
        if (expTree.l != null){ //check left
            string = preTraverse(expTree.l, string);}
        if (expTree.r != null && expTree.Data != "Let"){ //check right
            string = preTraverse(expTree.r, string);}
        return string;  //return constructed string
    }
}