//each operand class extends operatortree to invoke constructor of parent class
public class MinusTree extends OperatorTree {

    /**
     * Constructor
     * @param l
     * @param r
     */
    public MinusTree(ExpTree l, ExpTree r) {
        super(l, r, '-');
    }
}