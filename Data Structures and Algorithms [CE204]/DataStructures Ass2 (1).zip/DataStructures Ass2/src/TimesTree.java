//each operand class extends operatortree to invoke constructor of parent class

public class TimesTree extends OperatorTree {

    //constructor
    public TimesTree(ExpTree l, ExpTree r) {
        super(l, r, '*');
    }
}