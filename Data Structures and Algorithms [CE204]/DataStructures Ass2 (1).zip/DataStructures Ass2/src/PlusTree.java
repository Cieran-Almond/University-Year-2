//each operand class extends operatortree to invoke constructor of parent class

public class PlusTree extends OperatorTree {

    //constructor
    public PlusTree(ExpTree l, ExpTree r) {
        super(l, r, '+');
    }
}