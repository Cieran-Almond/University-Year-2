"""
createdeq, isemoty, left, right, addleft, addright, removeleft, removeright
"""
# exception class created to handle empty lists

class Empty(Exception):
    pass
# dqueue class created to hold functions
class ArrayQueue:
    # creates empty item list
    def __init__(self):
        self.items = []

    # string function for formatting the output of the contents of the list
    def __str__(self):
        bracket = "<"
        for i in range (len(self.items)):
            if (i != 0):
                bracket = bracket + str(self.items)[1:-1] + ','
                break
        bracket = bracket.strip(',') + ">"
        return bracket

    # is empty function, will return an empty list
    def isEmpty(self):
        return self.items == []

    # prints the queue contents if it isnt empty
    def printQueue(self):
        if self.isEmpty():
            raise Empty("Queue is empty")

        print ("Queue contents: " + self.data)

    # gets the left position of the list as long as the list isnt empty and returns it
    def left(self):
        if self.isEmpty():
            raise Empty("Queue is empty")
        return self.items[0]

    # gets the right position of the list as long as the list isnt empty and returns it
    def right(self):
        if self.isEmpty():
            raise Empty("Queue is empty")
        return self.items[-1]

    # adds to  the left position of the list and returns it
    def addLeft(self, item):
        self.items.insert(0, item)
        return item

    # adds to the right position of the list and returns it
    def addRight(self, item):
        self.items.append(item)
        return item

    # removes from the left position of the list and returns it as long as the queue is empty
    def removeLeft(self):
        if self.isEmpty():
            raise Empty("Queue is empty")
        return self.items.pop(0)

    # removes from the right position of the list and returns it as long as the queue is empty
    def removeRight(self):
        if self.isEmpty():
            raise Empty("Queue is empty")
        return self.items.pop()


# creates dequeue and tests via print statements


d = ArrayQueue()
print("Queue contents: " + str(d))
print("Is queue empty: " + str(d.isEmpty()))
print("Adding " + str(d.addLeft(3)) + " to left")
print("Adding " + str(d.addRight(5)) + " to right")
print("Queue contents: " + str(d))
print("Adding " + str(d.addRight(7)) + " to right")
print("Adding " + str(d.addLeft(10)) + " to left")
print("Queue contents: " + str(d))
print("Is queue empty: " + str(d.isEmpty()))
print("Calling left: " + str(d.left()) + " returned")
print("Calling right: " + str(d.right()) + " returned")
print("Removing " + str(d.removeRight()) + " from right")
print("Queue contents: " + str(d))
print("Removing " + str(d.removeLeft()) + " from left")
print("Queue contents: " + str(d))
print("Removing " + str(d.removeLeft()) + " from left")
print("Removing " + str(d.removeRight()) + " from right")
print("Queue contents: " + str(d))

# check error messages work on empty lists

try:
    print(d.left())
except Empty:
    print("Error: Left called on an empty list")

try:
    print(d.right())
except Empty:
    print("Error: Right called on an empty list")

try:
    print(d.removeRight())
except Empty:
    print("Error: removeRight called on an empty list")

try:
    print(d.removeLeft())
except Empty:
    print("Error: removeLeft called on an empty list")



