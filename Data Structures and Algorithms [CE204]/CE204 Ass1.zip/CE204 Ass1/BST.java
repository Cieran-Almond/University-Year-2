package Exercise2;

import java.util.LinkedList;
import java.util.Stack;

/**
 * Created by ca16873 on 29/01/2018.
 */
public class BST {
    private BTNode<Integer> root;

    public BST() {
        root = null;
    }

    public boolean find(Integer i) {
        BTNode<Integer> n = root;
        boolean found = false;

        while (n != null && !found) {
            int comp = i.compareTo(n.data);
            if (comp == 0)
                found = true;
            else if (comp < 0)
                n = n.left;
            else
                n = n.right;
        }

        return found;
    }

    public boolean insert(Integer i) {
        BTNode<Integer> parent = root, child = root;
        boolean goneLeft = false;

        while (child != null && i.compareTo(child.data) != 0) {
            parent = child;
            if (i.compareTo(child.data) < 0) {
                child = child.left;
                goneLeft = true;
            } else {
                child = child.right;
                goneLeft = false;
            }
        }

        if (child != null)
            return false;  // number already present
        else {
            BTNode<Integer> leaf = new BTNode<Integer>(i);
            if (parent == null) // tree was empty
                root = leaf;
            else if (goneLeft)
                parent.left = leaf;
            else
                parent.right = leaf;
            return true;
        }
    }

    //3 extra methods to be added for exercise 2

    public int nonleaves() {

        //create stack to store values of nonleaves (use pop and push)
        Stack<BTNode<Integer>> nonleaves = new Stack<>();
        BTNode<Integer> node = root;
        //return 0 if root is null
        if (root == null) {
            return 0;
        }
        //initalise count
        int i = 0;
        /*whiles traverse the left then right side of the trees, and their children
        counting the ones with no children
        */
        while (node != null) {
            nonleaves.push(node);
            node = node.left;
        }
        while (nonleaves.size() > 0) {
            node = nonleaves.pop();
            if (node.right != null) {
                node = node.right;

                while (node != null) {
                    nonleaves.push(node);
                    node = node.left;
                }
            } else if (node.left == null) {
                i++;
            }
        }
        return i;
    }

    public int depth() {
        //create stack to store values of depth (use pop and push)
        Stack<BTNode<Integer>> depth = new Stack<>();
        BTNode<Integer> node = root;

        if (root == null) {
            return 0;
        }
        //return 0 if root is null
        int i = 0;

        /*whiles traverse the left then right side of the trees, and their children
        to reach the bottom of the tree
        */

        while (node != null) {
            depth.push(node);
            node = node.left;
        }
        while (depth.size() > 0) {
            node = depth.pop();
            if (node.right != null) {
                node = node.right;

                while (node != null) {
                    depth.push(node);
                    node = node.left;
                    i++;
                }
            }
        }
        return i;
    }

    public int range(int min, int max) {

        //create stack to store values of depth (use pop and push)
        Stack<BTNode<Integer>> range = new Stack<>();
        BTNode<Integer> node = root;
        //return 0 if root is null
        if (root == null) {
            return 0;
        }
        //if max is less than min value, throw exception
        if (max < min) {
            throw new IllegalArgumentException();
        }

        //initalise counter
        int i = 0;

          /*whiles traverse the left then right side of the trees, and their children
        to find the range of the tree between set values
        */

        while (node != null) {
            range.push(node);
            node = node.left;
        }

        while (range.size() > 0) {
            node = range.pop();
            //incrememnt the count if the min and max values are between the given valuies of min and max of the range
            if (node.data >= min && node.data <= max) {
                i++;
            }
            if (node.right != null) {
                node = node.right;

                while (node != null) {
                    range.push(node);
                    node = node.left;
                }
            }
        }
        return i;
    }


        class BTNode<T> {
            T data;
            BTNode<T> left, right;

            BTNode(T o) {
                data = o;
                left = right = null;
            }
        }

}


